NETRUNNER RISING // website for netrunnerrising.neocities.org

UPLOAD (every release)
1. Sign in to Neocities and open your site's file manager (Edit Site).
2. Drag in everything from this folder: index.html, app.html, version.json, sw.js, manifest.json,
   and the fonts and icons folders. Replace the old files when asked.
That's it. Players get the update automatically:
 - iPhone/iPad and browsers: the next time they open the game while online.
 - Android app: it downloads the new version in the background and uses it the next time it opens.

WHAT THE FILES DO
 index.html     the game, installable on iPhone/iPad (Safari > Share > Add to Home Screen)
 app.html       the Android app's copy of the game (the app downloads this)
 version.json   the build number the Android app compares with its own
 sw.js          keeps the game working offline
 manifest.json  app name and icons for the Home Screen

INSTALL ON IPHONE / IPAD
1. Open https://netrunnerrising.neocities.org/ in Safari.
2. Tap Share, then "Add to Home Screen", then "Add".

Updates can change anything inside the game. Changes to the Android app itself (for example new permissions)
still need a new APK. Saves stay on each device; updates never touch them.

NETRUNNER RISING for iPhone & iPad

PUT IT ONLINE (once, free, with GitHub Pages)
1. Upload everything in this folder (index.html, sw.js, manifest.webmanifest, fonts/, icons/) to the root of
   https://github.com/InsightJokes/Netrunner-Rising
2. In the repo: Settings > Pages > Build and deployment > Source: "Deploy from a branch", Branch: main, folder: / (root). Save.
3. After a minute the game is live at https://insightjokes.github.io/Netrunner-Rising/
   (the "Download for iPhone & iPad" button in the game's Settings points there).

INSTALL ON IPHONE / IPAD
1. Open https://insightjokes.github.io/Netrunner-Rising/ in Safari.
2. Tap the Share button, then "Add to Home Screen", then "Add".
3. Open Netrunner from the Home Screen. It runs fullscreen and works offline.

Saves stay on the device. The home-screen app has its own saves, separate from Safari and from the Android app.

Netrunner Rising — Steam Deck borderless fullscreen
================================================

Site: https://netrunnerrising.neocities.org/

Chromium Flatpak in kiosk/app mode: no address bar, no tabs, no borders.
A controller layer is injected so you can play with the stick and A.

Controls
--------
  Left joystick         move the cyan highlight
  A                     select / confirm
  B                     back (or leave a text box)
  Steam + X             on-screen keyboard, for the handle name box

Right stick is ignored. In Gaming Mode, open the controller icon on the
game page and pick the Gamepad template (not Desktop). Desktop mode turns
the left stick into a mouse, which skips the highlight.

Install (Desktop Mode)
----------------------
1. Switch the Deck to Desktop Mode.
2. Unzip this folder, e.g. to ~/Downloads/netrunner-rising-deck
3. Konsole in that folder:

     chmod +x install.sh launch.sh
     ./install.sh

4. Launch "Netrunner Rising" from the application menu to test it.

Add to Gaming Mode
------------------
1. Still in Desktop Mode, open Steam.
2. Games -> Add a Non-Steam Game -> Browse.
3. Select:

     /home/deck/Applications/netrunner-rising/launch.sh

4. Rename the entry to Netrunner Rising.
5. Optional icon: netrunner-rising.png in that same folder.
6. Return to Gaming Mode, launch it, then set the Gamepad template.

Quit with Steam + B, or Alt+F4 in Desktop Mode.

Saves
-----
Browser profile (the 3 handles) is stored at:

  ~/.local/share/netrunner-rising

Delete that folder to wipe them.

Resolution
----------
Defaults to the Deck panel, 1280x800. Override with:

  NR_WIDTH=1920 NR_HEIGHT=1080 ./launch.sh

/* Netrunner Rising — Steam controller layer
   Left stick / D-pad moves a highlight. A activates. B goes back.
   Also accepts Arrow keys + Enter/Escape so a keyboard-style layout works. */
(function () {
  if (window.__nrPad) return;
  window.__nrPad = true;

  const DEAD = 0.42;
  const FIRST = 240;
  const REPEAT = 160;

  let focused = null;
  let held = null;
  let holdStart = 0;
  let lastMove = 0;
  let aPrev = false;
  let bPrev = false;
  let lastKeyAt = 0;

  const css = document.createElement("style");
  css.textContent = `
    .nr-pad-focus {
      outline: 3px solid #39f6ff !important;
      outline-offset: 3px !important;
      box-shadow: 0 0 0 1px #062028, 0 0 18px #39f6ff !important;
      position: relative;
      z-index: 99999;
    }
    #nr-pad-hint {
      position: fixed; left: 10px; bottom: 10px; z-index: 100000;
      background: rgba(4, 12, 20, 0.88); color: #9ff;
      font: 13px/1.3 "Share Tech Mono", ui-monospace, monospace;
      padding: 6px 10px; border: 1px solid #39f6ff; pointer-events: none;
      letter-spacing: 0.04em;
    }
  `;
  document.documentElement.appendChild(css);

  const hint = document.createElement("div");
  hint.id = "nr-pad-hint";
  hint.textContent = "LEFT STICK move   A select   B back";
  document.documentElement.appendChild(hint);
  setTimeout(() => { hint.style.transition = "opacity .6s"; hint.style.opacity = "0"; }, 5000);
  setTimeout(() => hint.remove(), 5800);

  function visible(el) {
    if (!el || el.disabled || el.getAttribute("aria-hidden") === "true") return false;
    const r = el.getBoundingClientRect();
    if (r.width < 6 || r.height < 6) return false;
    if (r.bottom < 0 || r.top > innerHeight || r.right < 0 || r.left > innerWidth) return false;
    const s = getComputedStyle(el);
    if (s.display === "none" || s.visibility === "hidden" || Number(s.opacity) === 0) return false;
    if (s.pointerEvents === "none") return false;
    return true;
  }

  function candidates() {
    const sel = "button, a[href], input, select, textarea, .cell, [data-act], [role='button']";
    const seen = new Set();
    const out = [];
    for (const el of document.querySelectorAll(sel)) {
      if (seen.has(el) || !visible(el)) continue;
      seen.add(el);
      out.push(el);
    }
    return out;
  }

  function paint() {
    for (const el of document.querySelectorAll(".nr-pad-focus")) el.classList.remove("nr-pad-focus");
    if (focused && document.contains(focused) && visible(focused)) {
      focused.classList.add("nr-pad-focus");
      focused.scrollIntoView({ block: "nearest", inline: "nearest" });
    } else {
      focused = null;
    }
  }

  function ensure() {
    const list = candidates();
    if (!list.length) { focused = null; paint(); return; }
    if (!focused || !document.contains(focused) || !visible(focused) || !list.includes(focused)) {
      focused = list[0];
    }
    paint();
  }

  function move(dx, dy) {
    const list = candidates();
    if (!list.length) return;
    if (!focused || !list.includes(focused)) focused = list[0];
    const r = focused.getBoundingClientRect();
    const cx = r.left + r.width / 2;
    const cy = r.top + r.height / 2;
    let best = null;
    let bestScore = Infinity;
    for (const el of list) {
      if (el === focused) continue;
      const er = el.getBoundingClientRect();
      const vx = er.left + er.width / 2 - cx;
      const vy = er.top + er.height / 2 - cy;
      const dot = vx * dx + vy * dy;
      if (dot <= 6) continue;
      const dist = Math.hypot(vx, vy) || 1;
      const align = dot / dist;
      if (align < 0.4) continue;
      const score = dist * (1.15 - align);
      if (score < bestScore) { bestScore = score; best = el; }
    }
    if (best) { focused = best; paint(); }
  }

  function typing() {
    const a = document.activeElement;
    return a && (a.tagName === "INPUT" || a.tagName === "TEXTAREA") && a !== document.body;
  }

  function activate() {
    ensure();
    if (!focused) return;
    if (focused.tagName === "INPUT" || focused.tagName === "TEXTAREA") {
      focused.focus();
      return;
    }
    focused.click();
  }

  function back() {
    if (typing()) { document.activeElement.blur(); ensure(); return; }
    const list = candidates();
    const hit = list.find((el) => {
      const act = (el.dataset && el.dataset.act) || "";
      const t = (el.innerText || "").trim().toLowerCase();
      return act === "toTitle" || act === "toHub" || act === "toProfiles" ||
        act === "toMap" || act === "abort" || act === "closeModal" ||
        act === "closePhase" || act === "closeStory" || act === "cancelDel" ||
        t === "back" || t === "abort" || t === "cancel" || t === "close";
    });
    if (hit) hit.click();
  }

  document.addEventListener("keydown", (e) => {
    if (e.target && (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA")) {
      if (e.key === "Escape") { e.target.blur(); e.preventDefault(); }
      return;
    }
    const map = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] };
    if (map[e.key]) {
      e.preventDefault();
      e.stopPropagation();
      lastKeyAt = performance.now();
      ensure();
      move(map[e.key][0], map[e.key][1]);
    } else if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      e.stopPropagation();
      lastKeyAt = performance.now();
      activate();
    } else if (e.key === "Escape" || e.key === "Backspace") {
      e.preventDefault();
      e.stopPropagation();
      back();
    }
  }, true);

  function poll() {
    // If the host bridge is feeding Arrow/Enter, ignore the raw pad
    // so a single flick doesn't move twice.
    if (window.__nrBridge) {
      requestAnimationFrame(poll);
      return;
    }
    const pads = navigator.getGamepads ? navigator.getGamepads() : [];
    let pad = null;
    for (const p of pads) if (p && p.connected) { pad = p; break; }
    if (pad && performance.now() - lastKeyAt > 80 && !typing()) {
      ensure();
      // Left joystick only. axes[0]/[1] is the left stick on Deck and Steam Controller.
      const ax = pad.axes[0] || 0;
      const ay = pad.axes[1] || 0;
      let dx = 0, dy = 0;
      if (ax < -DEAD) dx = -1;
      else if (ax > DEAD) dx = 1;
      if (ay < -DEAD) dy = -1;
      else if (ay > DEAD) dy = 1;
      const now = performance.now();
      const dir = dx || dy ? dx + "," + dy : null;
      if (dir) {
        if (dir !== held) { held = dir; holdStart = now; lastMove = now; move(dx, dy); }
        else if (now - holdStart > FIRST && now - lastMove > REPEAT) { lastMove = now; move(dx, dy); }
      } else held = null;
      const a = !!(pad.buttons[0] && pad.buttons[0].pressed);
      const b = !!(pad.buttons[1] && pad.buttons[1].pressed);
      if (a && !aPrev) activate();
      if (b && !bPrev) back();
      aPrev = a; bPrev = b;
    }
    requestAnimationFrame(poll);
  }

  new MutationObserver(() => ensure()).observe(document.documentElement, { childList: true, subtree: true });
  window.addEventListener("resize", ensure);
  setTimeout(ensure, 300);
  requestAnimationFrame(poll);
})();

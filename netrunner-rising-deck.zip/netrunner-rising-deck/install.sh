#!/usr/bin/env bash
# Install Netrunner Rising as a borderless fullscreen app on Steam Deck.
# Run this in Desktop Mode, from Konsole.
set -euo pipefail

APP_DIR="${HOME}/Applications/netrunner-rising"
DESKTOP_DIR="${HOME}/.local/share/applications"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "== Netrunner Rising / Steam Deck installer =="
echo "Target: ${APP_DIR}"

if ! command -v flatpak >/dev/null 2>&1; then
  echo "flatpak is not installed. This script is meant for SteamOS / Steam Deck." >&2
  exit 1
fi

echo "-- Adding Flathub (ignored if it is already there)"
flatpak remote-add --if-not-exists --user flathub https://flathub.org/repo/flathub.flatpakrepo || true

echo "-- Installing Chromium Flatpak (the kiosk / no-borders browser)"
flatpak install -y --user flathub org.chromium.Chromium

echo "-- Writing launcher"
mkdir -p "$APP_DIR" "$DESKTOP_DIR"
cp "$SCRIPT_DIR/launch.sh" "$APP_DIR/launch.sh"
cp "$SCRIPT_DIR/pad.js" "$APP_DIR/pad.js"
cp "$SCRIPT_DIR/pad_bridge.py" "$APP_DIR/pad_bridge.py"
mkdir -p "$APP_DIR/ext"
cp "$SCRIPT_DIR/ext/manifest.json" "$APP_DIR/ext/manifest.json"
cp "$SCRIPT_DIR/pad.js" "$APP_DIR/ext/pad.js"
cp "$SCRIPT_DIR/netrunner-rising.png" "$APP_DIR/netrunner-rising.png"
chmod +x "$APP_DIR/launch.sh" "$APP_DIR/pad_bridge.py"

# Desktop entry with this user's real home path baked in.
sed "s|__HOME__|${HOME}|g" "$SCRIPT_DIR/netrunner-rising.desktop" \
  > "$DESKTOP_DIR/netrunner-rising.desktop"
chmod +x "$DESKTOP_DIR/netrunner-rising.desktop"

# Also drop a copy on the Desktop so it is easy to right-click -> Add to Steam.
if [[ -d "${HOME}/Desktop" ]]; then
  cp "$DESKTOP_DIR/netrunner-rising.desktop" "${HOME}/Desktop/Netrunner Rising.desktop"
  chmod +x "${HOME}/Desktop/Netrunner Rising.desktop"
fi

update-desktop-database "$DESKTOP_DIR" >/dev/null 2>&1 || true

echo
echo "Installed."
echo
echo "Desktop Mode: open the application menu and launch \"Netrunner Rising\"."
echo "It opens https://netrunnerrising.neocities.org/ fullscreen, no borders."
echo "Left stick moves the highlight. A selects. B goes back."
echo "Your 3 profiles / saves live in: ${HOME}/.local/share/netrunner-rising"
echo
echo "Gaming Mode:"
echo "  1. Stay in Desktop Mode."
echo "  2. Open Steam."
echo "  3. Games -> Add a Non-Steam Game to My Library -> Browse."
echo "  4. Pick ${APP_DIR}/launch.sh"
echo "     (or right-click the Desktop icon -> Add to Steam)."
echo "  5. In the shortcut properties, rename it to Netrunner Rising."
echo "  6. Return to Gaming Mode and launch it."
echo "  7. Controller icon -> Templates -> Gamepad"
echo "     (not the Desktop template). Stick = move, A = select, B = back."
echo
echo "Quit the kiosk with Steam + B, or Alt+F4 in Desktop Mode."

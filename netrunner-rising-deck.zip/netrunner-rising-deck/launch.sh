#!/usr/bin/env bash
# Netrunner Rising — Steam Deck borderless fullscreen launcher
# Joystick moves the highlight, A selects, B goes back.
set -euo pipefail

URL="https://netrunnerrising.neocities.org/"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROFILE="${HOME}/.local/share/netrunner-rising"
mkdir -p "$PROFILE"

WIDTH="${NR_WIDTH:-1280}"
HEIGHT="${NR_HEIGHT:-800}"
DBG_PORT="${NR_DBG_PORT:-9223}"

# Controller bridge: injects the highlight layer and maps stick/A/B.
# Dies with this script.
if command -v python3 >/dev/null 2>&1; then
  python3 "$HERE/pad_bridge.py" --port "$DBG_PORT" --script "$HERE/pad.js" \
    >/tmp/nr-pad.log 2>&1 &
  BRIDGE_PID=$!
  trap 'kill "$BRIDGE_PID" 2>/dev/null || true' EXIT
fi

CHROME_FLAGS=(
  --remote-debugging-port="$DBG_PORT"
  --remote-allow-origins=*
  --load-extension="$HERE/ext"
  --disable-features=DisableLoadExtensionCommandLineSwitch,Translate,TranslateUI,InfiniteSessionRestore
  --user-data-dir="$PROFILE"
  --app="$URL"
  --kiosk
  --start-fullscreen
  --no-first-run
  --no-default-browser-check
  --disable-translate
  --disable-session-crashed-bubble
  --disable-infobars
  --autoplay-policy=no-user-gesture-required
  --password-store=basic
  --check-for-update-interval=31536000
  --window-size="${WIDTH},${HEIGHT}"
  --window-position=0,0
  --force-device-scale-factor=1
  --ozone-platform=x11
)

if flatpak info org.chromium.Chromium >/dev/null 2>&1; then
  # --device=all lets the page see the gamepad if the bridge can't.
  exec flatpak run --device=all --branch=stable --arch=x86_64 \
    org.chromium.Chromium "${CHROME_FLAGS[@]}"
fi

if flatpak info org.mozilla.firefox >/dev/null 2>&1; then
  mkdir -p "$PROFILE/firefox"
  exec flatpak run --device=all --branch=stable --arch=x86_64 \
    org.mozilla.firefox --kiosk --new-instance -profile "$PROFILE/firefox" "$URL"
fi

echo "Netrunner Rising: no browser Flatpak found. Run install.sh first." >&2
exit 1

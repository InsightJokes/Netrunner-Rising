#!/usr/bin/env python3
"""Inject the controller layer and drive it from the LEFT joystick only.

Reads the Steam Deck / Steam Controller left stick (ABS_X / ABS_Y) and
A/B, then sends Arrow / Enter / Escape into the kiosk page.
Stdlib only.
"""
import json
import os
import select
import socket
import struct
import sys
import time
import urllib.request

PORT = 9223
SCRIPT_PATH = None
args = sys.argv[1:]
for i, a in enumerate(args):
    if a == "--port" and i + 1 < len(args):
        PORT = int(args[i + 1])
    if a == "--script" and i + 1 < len(args):
        SCRIPT_PATH = args[i + 1]

# evdev
EV_KEY = 0x01
EV_ABS = 0x03
ABS_X = 0x00   # left stick X
ABS_Y = 0x01   # left stick Y
BTN_SOUTH = 304  # A
BTN_EAST = 305   # B
BTN_A = 304
BTN_B = 305

INPUT_EVENT = struct.Struct("llHHi")  # timeval(sec, usec) + type, code, value on 64-bit
DEAD = 0.38


def _IOC(direction, typ, nr, size):
    return (direction << 30) | (size << 16) | (typ << 8) | nr


def EVIOCGNAME(length):
    return _IOC(2, ord("E"), 0x06, length)


def EVIOCGABS(axis):
    return _IOC(2, ord("E"), 0x40 + axis, 24)


def load_script():
    path = SCRIPT_PATH or os.path.join(os.path.dirname(os.path.abspath(__file__)), "pad.js")
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def http_json(url):
    with urllib.request.urlopen(url, timeout=2) as r:
        return json.loads(r.read().decode())


class WS:
    def __init__(self, url):
        rest = url.split("://", 1)[1]
        hostport, path = rest.split("/", 1)
        host, port = hostport.split(":")
        self.sock = socket.create_connection((host, int(port)), timeout=5)
        key = "dGhlIHNhbXBsZSBub25jZQ=="
        req = (
            f"GET /{path} HTTP/1.1\r\n"
            f"Host: {hostport}\r\n"
            "Upgrade: websocket\r\n"
            "Connection: Upgrade\r\n"
            f"Sec-WebSocket-Key: {key}\r\n"
            "Sec-WebSocket-Version: 13\r\n\r\n"
        )
        self.sock.sendall(req.encode())
        buf = b""
        while b"\r\n\r\n" not in buf:
            buf += self.sock.recv(4096)
        self.buf = b""

    def send(self, method, params=None):
        msg = {"id": 1, "method": method}
        if params:
            msg["params"] = params
        data = json.dumps(msg).encode()
        if len(data) < 126:
            header = bytes([0x81, 0x80 | len(data)])
        elif len(data) < 65536:
            header = bytes([0x81, 0x80 | 126]) + struct.pack(">H", len(data))
        else:
            header = bytes([0x81, 0x80 | 127]) + struct.pack(">Q", len(data))
        mask = os.urandom(4)
        masked = bytes(b ^ mask[i % 4] for i, b in enumerate(data))
        self.sock.sendall(header + mask + masked)

    def drain(self, seconds=0.3):
        end = time.time() + seconds
        while time.time() < end:
            self.sock.settimeout(0.05)
            try:
                chunk = self.sock.recv(65536)
                if not chunk:
                    break
            except socket.timeout:
                pass


def find_page():
    tabs = http_json(f"http://127.0.0.1:{PORT}/json")
    for t in tabs:
        if t.get("type") == "page" and t.get("webSocketDebuggerUrl"):
            return t["webSocketDebuggerUrl"]
    return None


def dev_name(fd):
    import fcntl
    buf = bytearray(256)
    try:
        fcntl.ioctl(fd, EVIOCGNAME(256), buf)
        return buf.split(b"\x00", 1)[0].decode(errors="ignore")
    except OSError:
        return ""


def abs_range(fd, axis):
    import fcntl
    buf = bytearray(24)
    try:
        fcntl.ioctl(fd, EVIOCGABS(axis), buf)
        value, minimum, maximum, _fuzz, _flat, _res = struct.unpack("iiiiii", buf)
        return minimum, maximum
    except OSError:
        return -32767, 32767


def open_left_stick():
    """Open the event device whose ABS_X/ABS_Y is the left joystick.
    Prefer a Steam Deck / Steam Controller / Xbox-style pad."""
    import fcntl
    base = "/dev/input"
    if not os.path.isdir(base):
        return []
    found = []
    for name in sorted(os.listdir(base)):
        if not name.startswith("event"):
            continue
        path = os.path.join(base, name)
        try:
            fd = os.open(path, os.O_RDONLY | os.O_NONBLOCK)
        except OSError:
            continue
        label = dev_name(fd)
        # Must expose a left stick.
        xmin, xmax = abs_range(fd, ABS_X)
        if xmax <= xmin:
            os.close(fd)
            continue
        score = 0
        low = label.lower()
        if "deck" in low or "steam" in low or "valve" in low:
            score += 5
        if "xbox" in low or "x-box" in low or "controller" in low or "gamepad" in low:
            score += 3
        found.append((score, label, fd, abs_range(fd, ABS_X), abs_range(fd, ABS_Y)))
    found.sort(key=lambda t: -t[0])
    if not found:
        return []
    # Keep the best pad only, so a mouse or right-stick device can't steal it.
    score, label, fd, xr, yr = found[0]
    for _s, _l, other, _a, _b in found[1:]:
        os.close(other)
    print(f"pad bridge: left stick from '{label}'", file=sys.stderr)
    return [(fd, xr, yr)]


def main():
    script = load_script()
    ws_url = None
    for _ in range(80):
        try:
            ws_url = find_page()
            if ws_url:
                break
        except Exception:
            pass
        time.sleep(0.25)
    if not ws_url:
        print("pad bridge: no browser debug port", file=sys.stderr)
        return

    ws = WS(ws_url)
    ws.send("Page.enable")
    ws.send("Page.addScriptToEvaluateOnNewDocument", {"source": script})
    ws.send("Runtime.evaluate", {"expression": script})
    ws.drain(0.4)

    pads = open_left_stick()
    if not pads:
        print("pad bridge: no left-stick device — using in-page gamepad", file=sys.stderr)
        while True:
            time.sleep(5)
        return

    ws.send("Runtime.evaluate", {"expression": "window.__nrBridge = true;"})
    ws.send("Page.addScriptToEvaluateOnNewDocument", {"source": "window.__nrBridge = true;"})
    ws.drain(0.2)

    fd, (xmin, xmax), (ymin, ymax) = pads[0]
    x = y = 0.0
    btn = {}
    prev = {}
    held = None
    hold_start = 0.0
    last_repeat = 0.0

    def norm(value, lo, hi):
        if hi <= lo:
            return 0.0
        return (value - lo) / (hi - lo) * 2.0 - 1.0

    def key(name, code, vk, down):
        ws.send("Input.dispatchKeyEvent", {
            "type": "keyDown" if down else "keyUp",
            "key": name,
            "code": code,
            "windowsVirtualKeyCode": vk,
            "nativeVirtualKeyCode": vk,
        })

    def tap(name, code, vk):
        key(name, code, vk, True)
        key(name, code, vk, False)

    while True:
        r, _, _ = select.select([fd], [], [], 0.02)
        if r:
            try:
                data = os.read(fd, INPUT_EVENT.size * 32)
            except OSError:
                data = b""
            for i in range(0, len(data) - INPUT_EVENT.size + 1, INPUT_EVENT.size):
                _sec, _usec, typ, code, value = INPUT_EVENT.unpack_from(data, i)
                if typ == EV_ABS and code == ABS_X:
                    x = norm(value, xmin, xmax)
                elif typ == EV_ABS and code == ABS_Y:
                    y = norm(value, ymin, ymax)
                elif typ == EV_KEY and code in (BTN_SOUTH, BTN_EAST, BTN_A, BTN_B):
                    btn[code] = value

        dx = -1 if x < -DEAD else 1 if x > DEAD else 0
        dy = -1 if y < -DEAD else 1 if y > DEAD else 0
        now = time.time()
        direction = (dx, dy) if (dx or dy) else None
        if direction != held:
            held = direction
            hold_start = now
            last_repeat = now
            if dx < 0:
                tap("ArrowLeft", "ArrowLeft", 37)
            elif dx > 0:
                tap("ArrowRight", "ArrowRight", 39)
            if dy < 0:
                tap("ArrowUp", "ArrowUp", 38)
            elif dy > 0:
                tap("ArrowDown", "ArrowDown", 40)
        elif direction and now - hold_start > 0.22 and now - last_repeat > 0.15:
            last_repeat = now
            if dx < 0:
                tap("ArrowLeft", "ArrowLeft", 37)
            elif dx > 0:
                tap("ArrowRight", "ArrowRight", 39)
            if dy < 0:
                tap("ArrowUp", "ArrowUp", 38)
            elif dy > 0:
                tap("ArrowDown", "ArrowDown", 40)

        for code, name, kcode, vk in (
            (BTN_SOUTH, "Enter", "Enter", 13),
            (BTN_EAST, "Escape", "Escape", 27),
        ):
            v = btn.get(code, 0)
            was = prev.get(code, 0)
            if v and not was:
                tap(name, kcode, vk)
            prev[code] = v


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
